# MobileVLA-R1 RGB RL 专用 vLLM 适配（session006）

本目录为独立开发批次。固定发布方 `AIGeeksGroup/MobileVLA-R1` revision `0c757f3e9d1b95d8416b42e7089e1c04f3e6118a` 的 `weight/rl/`，对应源码 commit `9d98cce3b623dfddf479740d78869ec30364b75a`。它不是赛事 `BAAI` 别名等价性的官方证明；没有把 RGB-only 配置冒称 RGB-D / point。尚未取得本轮 GPU 结果，不计作完成赛题。

## 1. 实际适配内容

| 组件 | 专用行为 | CPU 依据 |
| --- | --- | --- |
| Llama3 8B | 原生 vLLM Llama 实现、原始 291 个参数键、vocab 128259 | 固定 checkpoint JSON；实际下载后检查 safetensors header |
| SigLIP | 原生 vLLM SigLIP；前 26 层，保留 `hidden_states[-2]` 的全部 729 patch，不做末层 post norm / pooling head | 固定 vLLM 0.18.1 源码；`-2 + 27 + 1 = 26` |
| 投影 | 原始 2×2 `DownSampleBlock`、奇数网格补零、LN(4608)、Linear(4608→4096)、GELU、Linear(4096→4096) | 真实发布方 AST 定义、同权重 CPU 数值逐元素一致 |
| 观察序列 | 每帧 384×384，27×27 patch 变为 14×14=196 token，多帧顺序不变 | 8 帧与奇偶网格真实 Torch 比较 |
| tokenizer | 仅追加运行时 `<image>` 哨兵 128259，原始其他 token IDs 不变；LLM embedding 不新增行 | 发布方真实 tokenizer.json、1/8 帧 token 序列比较 |
| 模板 | 发布方 inference.py 的 `llama_3` 默认 system、单轮/多轮 separator | 固定 `Conversation` AST 的实际输出逐字比较；原 tokenizer_config 内模板保留 |
| 权重加载 | 四个 LLM shard 硬链接至派生小目录；vision/projector 通过原生 `DefaultModelLoader.secondary_weights` 分目录加载 | native loader 源码接口核查；所有真实参数仍受原生 strict loaded-parameter 检查 |
| 框架注册 | `vllm.general_plugins` 注册独立 `MobileVLAForConditionalGeneration006` 类及独立多模态 processor | CPU entry point 发现；实际 native import / GPU 运行另记 |

插件通过 `PYTHONPATH` 中的独立 `.dist-info/entry_points.txt` 发现，无需安装到 native 环境。保持原 DAS 平台插件发现：不能把全局 `VLLM_PLUGINS` 单独设为本插件名，因为该变量也会过滤平台插件；若已有显式列表，runtime 只追加本插件名。

新增配置采用标准 `LlavaConfig` 容器表达组件尺寸，专用类实现上述差异。它没有只将 architecture 改成标准 LLaVA 后忽略 projector、tokenizer 或权重布局。

本轮仅支持 TP1、原 BF16、最多 8 张 RGB 图、开发上下文 4096。原 checkpoint 的 LLM max position 为 8192；没有擅自扩展为 16K/32K。4096 开发服务不能替代完整 T02 性能矩阵。

## 2. 权重提取与完整性

[rl-entry-plan.json](rl-entry-plan.json) 固定 16 项必需文件，包括六份 safetensors、九份 JSON 和真实 tokenizer.json。压缩 payload 为 13,434,605,378 B，解压合计 16,997,621,949 B；不读取 SFT checkpoint、trainer_state 或 `.DS_Store`。

下载器由外部脚本按固定 revision 对每个 ZIP local header 与压缩 payload 做精确 Range、跨 1 GiB 分卷拆分、有限流式 deflate、CRC32 / 大小检查和 SHA256 记录。`prepare` 强制检查 root 下载器产生的 `mobilevla-selected-rgb-rl-receipt-006-v1`，16 项集合、目录身份、CRC、长度和压缩方法全部吻合后，再重算实际文件 SHA256、核对 safetensors header。

工具修订002额外封存八个派生小文件的字节数与SHA256：config、tokenizer、tokenizer_config、chat-template、index、preprocessor、generation和special_tokens。`prepare-receipt`不自引用，四个硬链接weight仍由原件SHA与samefile核验。`runtime.checkpoint`即使关闭weight完整hash也先核对八项固定集合、实际小文件内容与准备目录身份，拒绝漏项、null digest、派生tokenizer/模板/source-path变更、软链接与父目录漂移。001工具ZIP与原始回执保留历史，不能给它补写新结果。

**只读部分 Range 无法核验发布方整个 LFS 分卷 SHA256。** 本目录明确保留 `full_lfs_parts_sha_verified=false`。固定 HTTPS revision、ZIP CRC、局部/本地 SHA 与全分卷 LFS 认证的范围不同，不混用。

## 3. CPU 预备命令

在项目根目录使用 Windows PowerShell：

```powershell
python -m unittest discover -s tests -p test_mobilevla_session006.py -v
```

远端无卡 Notebook 中，解压本工具到独立项目目录，设置当前工具路径。`prepare` 需要逐文件读回 17 GB 原件，但不加载模型，不使用 GPU。输出目录必须不存在，且与原件处于同一文件系统，以便硬链接省去模型副本；不静默退回复制。

```bash
export PYTHONPATH="$PWD/candidates/mobilevla-r1-session006${PYTHONPATH:+:$PYTHONPATH}"
/usr/bin/python -B -m mobilevla_bw006.prepare \
  --source /root/private_data/guoxin-candidates/models/mobilevla-r1-rl006/weight/rl \
  --receipt /root/private_data/guoxin-candidates/models/mobilevla-r1-rl006/extraction-receipt.json \
  --output /root/private_data/guoxin-candidates/models/mobilevla-r1-derived006
```

## 4. GPU 实验入口

需先由平台给单张 BW 64GB 设置自动关机、GPU 设备出现，并确认没有别的服务占用本实验设备。工具本身不创建平台实例、不安装/覆盖 native Torch、vLLM、Transformers，不执行发布方 CUDA 安装脚本。

```bash
bash tasks/mobilevla-r1-rl-bw-vllm/run.sh --dry-run --run-id 654118905a9e4fd8a5d5abe88a0ca97a
bash tasks/mobilevla-r1-rl-bw-vllm/pilot.sh
```

`pilot.sh` 生成 32 hex run ID，使用已有 owned supervisor，结束/失败均执行精确 run ID 停止；保存实际配置、server/supervisor 日志、state 和结果。平台自动关机与进程最长 1800 秒分别约束资源和服务；代码不会声明这些约束已实际生效，须看真实回执。外层可使用不超过本轮预算的 `timeout`。

服务 entry points 为 `env_check.sh`、`run.sh`、`smoke.sh`、`verify.sh`、`bench.sh`、`stop.sh`。`verify/bench` 复用官方材料门禁，缺 evaluator / data / baseline 时不能产生通过结果；功能 smoke 的非空文本不能代表导航正确率。

独立 HF 组件开发参考入口如下，需要先停止 vLLM 释放 GPU。它组合原权重与已做 source parity 的 projector，记录原 `-200` 哨兵、像素/特征 SHA、实际 token IDs 和输出，不伪称执行了发布方 wrapper 或官方 baseline。

```bash
/usr/bin/python -B -m mobilevla_bw006.reference_rgb \
  --source /root/private_data/guoxin-candidates/models/mobilevla-r1-rl006/weight/rl \
  --image tasks/mobilevla-r1-rl-bw-vllm/fixtures/red.png \
  --max-new-tokens 32 --output evidence/session006/mobilevla-hf-reference-001.json
```

## 5. 已验证与未验证

Windows 真实 Torch CPU 回归27/27通过，原件日志在 `evidence/session006/mobilevla-cpu/windows-tests-002.*`。包括原19项真实发布方tokenization、同权重projector、多帧顺序、模板、实际adapter processor与原生prompt replacement，以及新增8项派生小文件封存/篡改/漏项/目录身份回归。001的19项日志继续原样保留。WSL的7个标准入口与pilot共8个shell文件已通过 `bash -n`，真实公共supervisor的32 hex ID launch dry-run通过；WSL仅有系统Python，未安装Torch/Transformers，因此没有假报WSL数值回归通过。

仍需 native DAS vLLM 实际导入、完整 RL checkpoint 提取和读回、真实 BW 模型加载/HTTP、多帧输出、独立 HF 参考比较及严格停止证据。正式 evaluator、固定数据、GPU baseline、BAAI 别名映射、RGB-D 范围和评审访问方式继续按事实记录缺项。`gpu_loaded=false`、`official_accuracy_passed=false`、`official_performance_passed=false`、`submission_ready=false`、`submitted=false`。

## 6. 版权

发布方源码及派生 DownSample / projector 保留 Apache-2.0 notice，见 [原许可](reference/UPSTREAM-LICENSE-APACHE-2.0.txt)。模型卡许可为 CC-BY-SA-4.0；Llama 底座继承权利范围需要随来源保留。新编适配代码仅保留版权说明，本目录没有擅自给整个派生仓库选择开源许可证。
