"""Publisher AST, real checkpoint tokenizer and real vLLM token-path regression."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
from typing import Mapping
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REVISION = ROOT / "revisions/mobilevla-bos003"
if not REVISION.exists():
    REVISION = ROOT
PUBLISHER = ROOT / "evidence/mobilevla-preflight-20261023/source"
sys.path.insert(0, str(REVISION / "candidates/mobilevla-r1-session006"))
sys.path.insert(0, str(ROOT / "scripts"))
from mobilevla_bw006.contract import tokenize_source_prompt, IMAGE_TOKEN_ID
from mobilevla_bw006.reference_rgb import source_prompt
from mobilevla_compare_policy006_003 import generation_policy, native_parameters, validate_completion, DEFAULT_QUESTION


class SourceTokenPathTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # The installed optional sklearn/scipy binaries are incompatible with
        # NumPy in this host. Disable only their availability flags in this CPU
        # test process so AutoTokenizer can be imported; no package/file edits.
        import transformers.utils.import_utils as flags
        flags._sklearn_available = False
        flags._scipy_available = False
        from transformers import AutoTokenizer, PreTrainedTokenizerFast
        cls.source = ROOT / "candidates/mobilevla-r1-session006/reference/rl-metadata"
        cls.tokenizer = AutoTokenizer.from_pretrained(str(cls.source / "llm"), local_files_only=True,
                                                      use_fast=False, legacy=False, padding_side="right")
        cls.tmp = tempfile.TemporaryDirectory()
        derived = json.loads((cls.source / "llm/tokenizer.json").read_text(encoding="utf-8"))
        derived["added_tokens"].append({"id": IMAGE_TOKEN_ID, "content": "<image>", "single_word": False,
                                        "lstrip": False, "rstrip": False, "normalized": False, "special": True})
        path = Path(cls.tmp.name) / "tokenizer.json"
        path.write_text(json.dumps(derived), encoding="utf-8")
        cls.derived = PreTrainedTokenizerFast(tokenizer_file=str(path), bos_token="<|begin_of_text|>",
                                              eos_token="<|eot_id|>", pad_token="[PAD]")
        source_method = next(n for n in ast.parse((PUBLISHER / "llava/mm_utils.py").read_text(encoding="utf-8")).body
                             if isinstance(n, ast.FunctionDef) and n.name == "tokenizer_image_token")
        namespace = {"IMAGE_TOKEN_INDEX": -200}
        exec(compile(ast.Module(body=[source_method], type_ignores=[]), "publisher-tokenizer", "exec"), namespace)
        cls.publisher_tokenize = staticmethod(namespace["tokenizer_image_token"])
        backend = REVISION / "candidates/mobilevla-r1-session006/mobilevla_bw006/backend.py"
        node = next(n for n in ast.parse(backend.read_text(encoding="utf-8")).body
                    if isinstance(n, ast.ClassDef) and n.name == "MobileVLAMultiModalProcessor")
        namespace = {"LlavaMultiModalProcessor": object, "tokenize_source_prompt": tokenize_source_prompt}
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(backend), "exec"), namespace)
        cls.adapter = namespace[node.name]()
        cls.adapter.info = SimpleNamespace(get_tokenizer=lambda: cls.derived)
        cls.adapter._apply_hf_processor_mm_only = lambda **kw: {}
        framework = ROOT / "candidates/mobilevla-r1-session006/framework-source/vllm-multimodal-processing-processor.py"
        tree = ast.parse(framework.read_text(encoding="utf-8"))
        method = next(n for owner in tree.body if isinstance(owner, ast.ClassDef) for n in owner.body
                      if isinstance(n, ast.FunctionDef) and n.name == "_apply_hf_processor_main")
        namespace = {"Mapping": Mapping, "MultiModalDataItems": object, "BatchFeature": dict}
        exec(compile(ast.Module(body=[method], type_ignores=[]), str(framework), "exec"), namespace)
        cls.real_native_main = staticmethod(namespace[method.name])

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_publisher_loader_source_and_files_match_fixed_Git_lock(self):
        lock = json.loads((PUBLISHER.parent / "source-file-lock.json").read_text(encoding="utf-8"))
        names = ["inference.py", "llava/model/llava_arch.py", "llava/model/language_model/builder.py", "llava/mm_utils.py", "llava/conversation.py"]
        for name in names:
            row = next(x for x in lock["files"] if x["path"] == name)
            self.assertEqual(hashlib.sha256((PUBLISHER / name).read_bytes()).hexdigest(), row["sha256"])
        builder = ast.parse((PUBLISHER / "llava/model/language_model/builder.py").read_text(encoding="utf-8"))
        function = next(n for n in builder.body if isinstance(n, ast.FunctionDef) and n.name == "build_llm_and_tokenizer")
        namespace = {"Tuple": tuple, "PreTrainedModel": object, "PreTrainedTokenizer": object,
                     "PretrainedConfig": object, "AutoConfig": SimpleNamespace(from_pretrained=lambda p: SimpleNamespace(architectures=["LlamaForCausalLM"])),
                     "AutoModelForCausalLM": SimpleNamespace(from_pretrained=lambda *a, **kw: SimpleNamespace(config=SimpleNamespace(hidden_size=4096))),
                     "has_tokenizer": lambda p: True, "osp": __import__("os").path}
        calls = []
        namespace["AutoTokenizer"] = SimpleNamespace(from_pretrained=lambda *a, **kw: calls.append(kw) or self.tokenizer)
        exec(compile(ast.Module(body=[function], type_ignores=[]), "publisher-builder", "exec"), namespace)
        namespace[function.name](str(self.source / "llm"), SimpleNamespace(model_dtype="object"))
        self.assertFalse(calls[0]["use_fast"])
        self.assertFalse(calls[0]["legacy"])

    def test_publisher_actual_tokenizer_preserves_two_BOS(self):
        self.assertEqual(type(self.tokenizer).__name__, "PreTrainedTokenizerFast")
        self.assertEqual(self.tokenizer("<|begin_of_text|>Hello").input_ids[:2], [128000, 128000])
        ids = self.publisher_tokenize(source_prompt(DEFAULT_QUESTION, 1), self.tokenizer)
        self.assertEqual(ids[:2], [128000, 128000])
        self.assertEqual(len(ids), 74)

    def test_real_native_tokens_main_path_matches_publisher_one_and_eight_frames(self):
        for frames in (1, 8):
            with self.subTest(frames=frames):
                prompt = source_prompt(DEFAULT_QUESTION, frames)
                rendered_ids = self.derived.encode(prompt, add_special_tokens=False)
                self.assertEqual(rendered_ids[:2], [128000, 128006])
                actual, _, applied = self.real_native_main(self.adapter, rendered_ids, None, {}, {}, enable_hf_prompt_update=True)
                expected = [IMAGE_TOKEN_ID if x == -200 else x for x in self.publisher_tokenize(prompt, self.tokenizer)]
                self.assertEqual(actual, expected)
                self.assertEqual(actual[:2], [128000, 128000])
                self.assertEqual(actual.count(IMAGE_TOKEN_ID), frames)
                self.assertFalse(applied)

    def test_failed_real_HTTP_raw_is_reproduced_and_new_path_fixes_upstream_input(self):
        path = ROOT / "dist/000-session007-mobile-comparison001.zip"
        with zipfile.ZipFile(path) as archive:
            record = json.loads(archive.read("comparison001/native-1.json"))
        self.assertEqual(len(record["actual_prompt_token_ids"]), 268)
        self.assertEqual(len(record["expected_expanded_prompt_token_ids"]), 269)
        prompt = record["source_prompt"]
        incoming = self.derived.encode(prompt, add_special_tokens=False)
        corrected = self.adapter._apply_hf_processor_tokens_only(incoming)
        expanded = []
        for token in corrected:
            expanded.extend([IMAGE_TOKEN_ID] * 196 if token == IMAGE_TOKEN_ID else [token])
        self.assertEqual(expanded, record["expected_expanded_prompt_token_ids"])
        self.assertNotEqual(expanded, record["actual_prompt_token_ids"])

    def test_publisher_sampling_EOS_is_single_and_native_ignores_file_defaults(self):
        policy = generation_policy(self.source, self.tokenizer, 32)
        self.assertEqual(policy["eos_token_ids"], [128009])
        self.assertEqual(native_parameters(policy)["stop_token_ids"], [128009])
        self.assertEqual(validate_completion([31, 128001], "length", None, {**policy, "max_new_tokens": 2}), [])
        self.assertIn("stop_finish_without_terminal_EOS", validate_completion([31, 128001], "stop", 128001, policy))
        text = (REVISION / "candidates/mobilevla-r1-session006/mobilevla_bw006/runtime.py").read_text(encoding="utf-8")
        self.assertIn('"--generation-config", "vllm"', text)

    def test_old_derived_receipt_and_unbound_source_are_rejected_before_loading(self):
        from mobilevla_bw006 import ARCHITECTURE, runtime
        with tempfile.TemporaryDirectory() as tmp:
            model = Path(tmp)
            (model / "config.json").write_text(json.dumps({"architectures": [ARCHITECTURE],
                "image_token_index": IMAGE_TOKEN_ID, "mobilevla_adapter_revision": "007-bos003"}))
            receipt = {"schema": "mobilevla-derived-hf-view-006-v2", "source_unchanged": True}
            (model / "prepare-receipt.json").write_text(json.dumps(receipt))
            with self.assertRaises(ValueError):
                runtime.checkpoint(model)
            receipt.update(schema="mobilevla-derived-hf-view-007-bos003-v1", adapter_revision="007-bos003",
                           adapter_source_files={"backend.py": "0" * 64})
            (model / "prepare-receipt.json").write_text(json.dumps(receipt))
            with self.assertRaisesRegex(ValueError, "adapter source identities differ"):
                runtime.checkpoint(model)


if __name__ == "__main__":
    unittest.main()
