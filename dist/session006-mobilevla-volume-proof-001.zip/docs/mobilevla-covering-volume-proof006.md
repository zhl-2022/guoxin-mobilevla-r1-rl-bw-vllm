# MobileVLA 选定 RL 的14卷发布SHA认证

该独立工具补齐已完成RL下载的来源认证，不改原提取receipt、模型文件、压缩缓存或冻结002。它不导入Torch、不使用GPU，不解压SFT条目，也不把无关分卷保存到磁盘。

## 1. 为什么只需再读取约0.55GB

选定16条RL的压缩payload几乎连续，位于 `weight.zip.part-am` 至 `part-az` 共14分卷。覆盖14完整卷总长13,986,961,311B，其中已缓存的选定压缩payload为13,434,605,378B，差额为552,355,933B，另有读取ZIP local header的少量重复元数据。

验证器按逻辑归档顺序重建每个覆盖卷的完整字节流：已选内容从完整owned压缩缓存读取，其余缺口从固定ModelScope revision做精确Range读取。缺口只更新SHA后丢弃；程序不保留完整分卷，不对SFT进行解压或解释。

## 2. 实际认证链

1. 固定reviewed downloader、plan及26卷公开来源锁的SHA256，拒绝不同输入。
2. 等待当前下载器释放transfer.lock，验证完成的原提取receipt、16成员集合、CRC/size元数据、缓存owner identity与完整压缩长度。
3. 校验每个local ZIP header，得到精确compressed payload起点，构造不重叠的selected mappings。
4. 对每个覆盖卷，完整重建所有字节，计算整卷SHA256，与发布方锁定的whole-part LFS SHA256比较。
5. 在同一次缓存读取中，重新计算每个选定compressed payload的SHA256，与原提取receipt的compressed_sha256比较，从而把先前的提取SHA链与认证后的压缩原件连起来。
6. 验证输入receipt与所有固定源锁前后不变，输出独立的新JSON证明。

只有14卷全匹配、16缓存SHA全匹配、原receipt及固定输入保持不变，状态才为 `completed_fourteen_covering_volumes_authenticated`。这证明选定RL compressed payload绑定到完整覆盖卷的发布SHA；16个实际解压文件仍由prepare/runtime按原提取SHA逐项读回，模型加载和评测另证。

`all_26_full_volume_bytes_verified` 始终为false，其余12个卷没有下载。原receipt中的partial认证范围保持历史原貌，不能给旧文件补写新的认证声明。

## 3. 运行

把独立ZIP与绑定安装器上传到 `/root`，执行安全安装器。安装器固定新目录，拒绝覆盖已有项目。原始selected下载应先完成并释放锁；可在无卡模式执行，默认总期限3600秒，gap预算600MiB。

```bash
/usr/bin/python -B /root/unpack_mobilevla_volume_proof006_001.py \
  /root/session006-mobilevla-volume-proof-001.zip

/usr/bin/python -B \
  /root/private_data/guoxin-mobilevla-volume-proof006-001/scripts/verify_mobilevla_covering_volumes_006.py \
  --output /root/mobilevla-covering-volume-proof006-001.json \
  --max-seconds 3600
```

默认模型目录仍为 `/root/private_data/guoxin-candidates/models/mobilevla-r1-rl006`。输出JSON包含每卷期望/实际SHA、selected cache精确映射、gap区间与局部SHA、16缓存哈希与receipt绑定、总网络字节和时间，不包含缺口原始内容。

## 4. 验证边界

Windows与WSL各7项真实CPU合成回归全部通过，包括跨卷重建、错误gap、错误cache内容、错误receipt compressed SHA、overlap、deadline及实际14卷成本核算。另一代理独立在两平台各复跑7/7并只读复核核心逻辑，未发现阻断项。

这些测试不等于实际14卷认证已完成；实际状态以远端新生成的proof JSON为准。本工具不评测模型，不声称GPU加载、正式准确率、性能或赛事提交成功。
