#!/usr/bin/env python3
"""Authenticate selected RL compressed bytes with complete covering LFS hashes.

Reconstructs each touched volume's byte stream from completed owned selected-entry
caches plus exact remote gaps. Gap bytes are only hashed and discarded; no SFT
entry is decompressed, no unrelated whole volume is saved, no model/GPU imported.
Original extraction receipt and002 tools remain unchanged.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import sys
import time

import download_mobilevla_selected_006 as transfer

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_DOWNLOADER = "24b9c8eb892064c34ab2461088d2b6c1d4489df80d39b2f7ed7919b5ccd443d1"
EXPECTED_PLAN = "95f4551a87fe6f693d6ffb8a22e3bff633e895c38d1b51824d576a4a5da15462"
EXPECTED_LOCK = "3fddb60021c87c76bf980b8b94bdaa979094140a7f4cd8d25c0d45ce4e309329"
MAX_GAP_BYTES = 600 * 1024 * 1024


def sha(data):
    return hashlib.sha256(data).hexdigest()


class CountingArchive:
    def __init__(self, archive):
        self.archive = archive
        self.network_bytes = 0
        self.calls = 0

    def read_range(self, offset, length):
        data = self.archive.read_range(offset, length)
        if len(data) != length:
            raise ValueError("Exact gap/header byte count differs")
        self.network_bytes += len(data)
        self.calls += 1
        return data


def volume_layout(parts):
    result = []
    cursor = 0
    for index, part in enumerate(parts):
        result.append({**part, "index": index, "start": cursor, "end": cursor + part["size"]})
        cursor += part["size"]
    return result


def verify_streams(parts, segments, archive, deadline, report):
    """Pure reconstruction core; no extraction, model mutation or output writes."""
    ordered = sorted(segments, key=lambda x: x["start"])
    if not ordered or len({x["path"] for x in ordered}) != len(ordered):
        raise ValueError("Expected nonempty unique selected compressed segments")
    layout = volume_layout(parts)
    total = layout[-1]["end"]
    for index, segment in enumerate(ordered):
        if not 0 <= segment["start"] < segment["end"] <= total:
            raise ValueError("Selected segment lies outside fixed volumes")
        if index and ordered[index - 1]["end"] > segment["start"]:
            raise ValueError("Selected compressed segments overlap")
        if not re.fullmatch("[0-9a-f]{64}", segment["expected_sha256"]):
            raise ValueError("Expected extraction receipt compressed SHA256")
        if Path(segment["cache_file"]).stat().st_size != segment["end"] - segment["start"]:
            raise ValueError("Complete compressed cache length differs")
    covered = [p for p in layout if any(s["start"] < p["end"] and s["end"] > p["start"] for s in ordered)]
    expected_gap = sum(x["size"] for x in covered) - sum(x["end"] - x["start"] for x in ordered)
    if not 0 <= expected_gap <= MAX_GAP_BYTES:
        raise ValueError("Covering-volume remote gap budget exceeds600MiB")
    report.update(covered_volumes_expected=len(covered), expected_gap_network_bytes=expected_gap,
                  parts=[], selected_cache_hashes=[], gap_network_bytes=0, cached_bytes_hashed=0,
                  all_selected_cache_SHA256_match_extraction_receipt=False,
                  selected_RL_payloads_cryptographically_bound_to_published_volume_SHA256=False)
    streams = {}
    cache_hashes = {x["path"]: hashlib.sha256() for x in ordered}
    initial_stats = {x["path"]: Path(x["cache_file"]).stat() for x in ordered}
    try:
        for part in covered:
            if not re.fullmatch("[0-9a-f]{64}", part["sha256"]):
                raise ValueError("Expected fixed publisher whole-volume SHA256")
            hasher = hashlib.sha256()
            cursor = part["start"]
            mappings = []
            gaps = []
            while cursor < part["end"]:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Coverage verification deadline exhausted")
                segment = next((s for s in ordered if s["start"] <= cursor < s["end"]), None)
                if segment is not None:
                    end = min(part["end"], segment["end"])
                    offset = cursor - segment["start"]
                    stream = streams.setdefault(segment["path"], None)
                    if stream is None:
                        stream = Path(segment["cache_file"]).open("rb")
                        streams[segment["path"]] = stream
                    stream.seek(offset)
                    mapping = {"path": segment["path"], "logical_start": cursor,
                               "part_offset": cursor - part["start"], "cache_offset": offset,
                               "bytes": end - cursor}
                    while cursor < end:
                        if time.monotonic() >= deadline:
                            raise TimeoutError("Coverage verification deadline exhausted")
                        count = min(transfer.CHUNK, end - cursor)
                        data = stream.read(count)
                        if len(data) != count:
                            raise ValueError("Complete selected cache was truncated during verification")
                        hasher.update(data)
                        cache_hashes[segment["path"]].update(data)
                        report["cached_bytes_hashed"] += count
                        cursor += count
                    mappings.append(mapping)
                else:
                    next_start = min((s["start"] for s in ordered if s["start"] > cursor), default=part["end"])
                    end = min(part["end"], next_start)
                    while cursor < end:
                        if time.monotonic() >= deadline:
                            raise TimeoutError("Coverage verification deadline exhausted")
                        count = min(transfer.CHUNK, end - cursor)
                        data = archive.read_range(cursor, count)
                        if len(data) != count:
                            raise ValueError("Exact remote gap length differs")
                        hasher.update(data)
                        gaps.append({"logical_start": cursor, "part_offset": cursor - part["start"],
                                     "bytes": count, "sha256": sha(data)})
                        report["gap_network_bytes"] += count
                        cursor += count
            actual = hasher.hexdigest()
            result = {"path": part["path"], "size": part["size"], "logical_start": part["start"],
                      "expected_sha256": part["sha256"], "actual_sha256": actual,
                      "sha256_matches": actual == part["sha256"],
                      "selected_cache_mappings": mappings, "remote_gap_ranges": gaps,
                      "source": part.get("modelscope_url", part.get("url"))}
            report["parts"].append(result)
            print(json.dumps({"event": "covering_volume_hashed", "path": part["path"],
                              "size": part["size"], "sha256_matches": result["sha256_matches"]}), flush=True)
            if not result["sha256_matches"]:
                raise ValueError("Complete covering volume SHA256 differs: " + part["path"])
        for segment in ordered:
            current = Path(segment["cache_file"]).stat()
            old = initial_stats[segment["path"]]
            if (current.st_size, current.st_ino, current.st_mtime_ns) != (old.st_size, old.st_ino, old.st_mtime_ns):
                raise ValueError("Selected cache changed during verification")
            actual = cache_hashes[segment["path"]].hexdigest()
            row = {"path": segment["path"], "compressed_size": segment["end"] - segment["start"],
                   "logical_start": segment["start"], "actual_compressed_sha256": actual,
                   "extraction_receipt_compressed_sha256": segment["expected_sha256"],
                   "sha256_matches": actual == segment["expected_sha256"]}
            report["selected_cache_hashes"].append(row)
            if not row["sha256_matches"]:
                raise ValueError("Authenticated compressed bytes differ from extraction receipt: " + segment["path"])
        if report["gap_network_bytes"] != expected_gap:
            raise ValueError("Reconstruction read more or fewer remote gap bytes than fixed coverage")
        report["all_selected_cache_SHA256_match_extraction_receipt"] = True
        report["selected_RL_payloads_cryptographically_bound_to_published_volume_SHA256"] = True
        return report
    finally:
        for stream in streams.values():
            if stream is not None:
                stream.close()


def build_segments(plan, lock, destination, archive):
    rows, parts = transfer.validated_locks(plan, lock)
    transfer.no_links(destination)
    if (destination / "transfer.lock").exists():
        raise RuntimeError("Wait for the existing selected-entry transfer to release its lock")
    receipt_path = destination / "extraction-receipt.json"
    transfer.no_links(receipt_path)
    receipt_raw = receipt_path.read_bytes()
    receipt = json.loads(receipt_raw)
    if (receipt.get("schema"), receipt.get("repo"), receipt.get("revision"),
        receipt.get("central_directory_sha256"), receipt.get("status"),
        receipt.get("verified_crc32_and_size")) != (
        "mobilevla-selected-rgb-rl-receipt-006-v1", transfer.MODEL, transfer.REVISION,
        transfer.CD_SHA, "completed", True
    ):
        raise ValueError("Expected completed exact selected-entry extraction receipt")
    extracted = {x["path"]: x for x in receipt["files"]}
    if len(receipt["files"]) != 16 or set(extracted) != {x["path"] for x in rows}:
        raise ValueError("Expected exact sixteen selected files in extraction receipt")
    segments = []
    for row in rows:
        cache = destination / ".selected-compressed-006" / (sha(row["path"].encode()) + ".deflate")
        identity_path = cache.with_suffix(".identity.json")
        transfer.no_links(cache)
        transfer.no_links(identity_path)
        expected_identity = {**row, "repo": transfer.MODEL, "revision": transfer.REVISION,
                             "central_directory_sha256": transfer.CD_SHA}
        if transfer.read(identity_path) != expected_identity or cache.stat().st_size != row["compressed_size"]:
            raise ValueError("Expected complete owned selected-entry cache: " + row["path"])
        entry = extracted[row["path"]]
        if (entry["size"], entry["crc32"], entry["compressed_size"], entry["compression_method"]) != (
            row["uncompressed_size"], row["crc32"], row["compressed_size"], row["compression_method"]
        ):
            raise ValueError("Extraction receipt differs from pinned selected member")
        start = transfer.payload_offset(archive, row)
        segments.append({"path": row["path"], "start": start, "end": start + row["compressed_size"],
                         "cache_file": str(cache), "expected_sha256": entry["compressed_sha256"]})
    return parts, segments, receipt_path, receipt_raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, default=ROOT / "candidates/mobilevla-r1-session006/rl-entry-plan.json")
    parser.add_argument("--volume-lock", type=Path, default=ROOT / "evidence/session006/source-mapping/mobilevla-volume-sources006.json")
    parser.add_argument("--destination", type=Path, default=transfer.BASE)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-seconds", type=int, default=3600)
    args = parser.parse_args()
    if args.output.exists() or not 60 <= args.max_seconds <= 7200:
        raise ValueError("Require new output and a60-7200 second deadline")
    if args.destination != transfer.BASE or sys.platform != "linux":
        raise ValueError("Actual verification is restricted to the dedicated SCNet Linux namespace")
    source_files = {"downloader": (Path(transfer.__file__), EXPECTED_DOWNLOADER),
                    "plan": (args.plan, EXPECTED_PLAN), "volume_lock": (args.volume_lock, EXPECTED_LOCK)}
    for label, (path, expected) in source_files.items():
        if sha(path.read_bytes()) != expected:
            raise ValueError("Expected exact reviewed input identity: " + label)
    started = time.monotonic()
    deadline = started + args.max_seconds
    report = {"schema": "mobilevla-selected-RL-covering-LFS-volumes-proof006-v1",
              "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "status": "failed",
              "source_sha256": {k: v[1] for k, v in source_files.items()},
              "all_26_full_volume_bytes_verified": False, "GPU_imported": False,
              "unrelated_whole_volumes_saved": False, "SFT_payloads_decompressed": False,
              "original_extraction_receipt_modified": False}
    archive = CountingArchive(transfer.RemoteArchive(transfer.read(args.volume_lock)["parts"], deadline))
    receipt_path = None
    receipt_raw = None
    try:
        plan, lock = transfer.read(args.plan), transfer.read(args.volume_lock)
        parts, segments, receipt_path, receipt_raw = build_segments(plan, lock, args.destination, archive)
        report["extraction_receipt_sha256"] = sha(receipt_raw)
        report["selected_payload_count"] = len(segments)
        verify_streams(parts, segments, archive, deadline, report)
        if len(report["parts"]) != 14 or len(report["selected_cache_hashes"]) != 16:
            raise ValueError("Expected exactly fourteen covering volumes and sixteen selected payloads")
        if receipt_path.read_bytes() != receipt_raw:
            raise ValueError("Original extraction receipt changed during verification")
        if any(sha(path.read_bytes()) != expected for path, expected in source_files.values()):
            raise ValueError("Reviewed verifier input changed during verification")
        report["status"] = "completed_fourteen_covering_volumes_authenticated"
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
        report["selected_RL_payloads_cryptographically_bound_to_published_volume_SHA256"] = False
    finally:
        report["ended_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
        report["elapsed_seconds"] = time.monotonic() - started
        report["all_network_bytes_including_local_headers"] = archive.network_bytes
        report["network_range_requests"] = archive.calls
        if receipt_path is not None and receipt_raw is not None:
            try:
                report["original_extraction_receipt_unchanged"] = receipt_path.read_bytes() == receipt_raw
            except OSError:
                report["original_extraction_receipt_unchanged"] = False
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("x", encoding="utf-8") as stream:
            json.dump(report, stream, ensure_ascii=False, indent=2)
        print(json.dumps({"output": str(args.output), "status": report["status"],
                          "covering_volumes": len(report.get("parts", [])),
                          "network_gap_bytes": report.get("gap_network_bytes"),
                          "selected_cache_count": len(report.get("selected_cache_hashes", [])),
                          "error": report.get("error")}, indent=2))
    return 0 if report["status"] == "completed_fourteen_covering_volumes_authenticated" else 2


if __name__ == "__main__":
    raise SystemExit(main())
