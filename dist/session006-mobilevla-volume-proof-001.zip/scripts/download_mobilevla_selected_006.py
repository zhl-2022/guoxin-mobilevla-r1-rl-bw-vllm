#!/usr/bin/env python3
"""Extract the fixed MobileVLA RL entries through exact HTTP ranges, without GPU.

Partial ZIP volumes are not authenticated by full-volume publisher LFS SHA256.
Each selected entry is checked against the fixed central-directory CRC and size;
compressed and extracted local SHA256 are recorded for reproducibility.
Copyright scope only; no new repository-wide license is granted.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import struct
import sys
import time
import urllib.request
import urllib.error
import uuid
import zlib

MODEL = "AIGeeksGroup/MobileVLA-R1"
REVISION = "0c757f3e9d1b95d8416b42e7089e1c04f3e6118a"
CD_SHA = "4abb56a8a5710e7a7b2ec6664146ae57bc02d67c7b67a9eefb1bf4ae20a73373"
BASE = Path("/root/private_data/guoxin-candidates/models/mobilevla-r1-rl006")
CHUNK = 8 * 1024 * 1024


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as out:
        json.dump(value, out, indent=2, ensure_ascii=False)
        out.write("\n")


def relative(value):
    path = PurePosixPath(value)
    if path.is_absolute() or "\\" in value or ":" in value or any(p in ("", ".", "..") for p in value.split("/")):
        raise ValueError("Unsafe archive path")
    if not value.startswith("weight/rl/"):
        raise ValueError("Only the selected RL namespace is accepted")
    return path


def no_links(path):
    if any(item.is_symlink() for item in (Path(path), *Path(path).parents)):
        raise ValueError("Symlink destination or ancestor refused")


def scan(path):
    sha = hashlib.sha256(); crc = 0; size = 0
    with Path(path).open("rb") as inp:
        while data := inp.read(CHUNK):
            size += len(data); sha.update(data); crc = zlib.crc32(data, crc)
    return {"size": size, "sha256": sha.hexdigest(), "crc32": f"{crc:08x}"}


def validated_locks(plan, lock):
    if (plan.get("repo"), plan.get("revision"), plan.get("central_directory_sha256")) != (MODEL, REVISION, CD_SHA):
        raise ValueError("Selected-entry source identity differs")
    if (lock.get("model_id"), lock.get("revision")) != (MODEL, REVISION):
        raise ValueError("ZIP volume identity differs")
    if len(plan["entries"]) != 16 or len({x["path"] for x in plan["entries"]}) != 16:
        raise ValueError("Exact selected-entry set differs")
    for row in plan["entries"]:
        relative(row["path"])
        if row["compression_method"] not in (0, 8) or row["flag_bits"] & 1 or row["is_dir"]:
            raise ValueError("Unsupported or encrypted selected ZIP entry")
    if len(lock["parts"]) != 26:
        raise ValueError("Expected 26 fixed source volumes")
    for i, row in enumerate(lock["parts"]):
        name = "weight.zip.part-a" + chr(ord("a") + i)
        url = f"https://huggingface.co/{MODEL}/resolve/{REVISION}/{name}"
        if row["path"] != name or row["url"] != url or not 0 < row["size"] <= 1073741824:
            raise ValueError("Volume order, size or immutable URL differs")
        if "modelscope_url" in row:
            revision = row.get("modelscope_revision", "")
            if not re.fullmatch("[0-9a-f]{40}", revision) or row["modelscope_url"] != f"https://modelscope.cn/models/BAAI/MobileVLA-R1/resolve/{revision}/{name}":
                raise ValueError("ModelScope immutable source differs")
    if any("modelscope_url" in row for row in lock["parts"]) and not lock.get("published_all_26_volume_hashes_equal"):
        raise ValueError("Mirror identity comparison has not completed")
    return plan["entries"], lock["parts"]


class OfficialRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        from urllib.parse import urlsplit
        u = urlsplit(new_url); host = u.hostname or ""
        if u.scheme != "https" or u.username or u.password or not any(host == x or host.endswith("." + x) for x in ("huggingface.co", "hf.co", "modelscope.cn")):
            raise ValueError("Redirect outside official download hosts")
        return super().redirect_request(request, response, code, message, headers, new_url)


class RemoteArchive:
    def __init__(self, parts, deadline):
        self.parts = parts; self.deadline = deadline
        self.opener = urllib.request.build_opener(OfficialRedirects())

    def read_range(self, offset, length):
        if offset < 0 or length <= 0 or length > CHUNK:
            raise ValueError("Invalid bounded archive read")
        result = bytearray(); origin = 0
        for part in self.parts:
            end = origin + part["size"]
            if origin <= offset < end:
                start = offset - origin; count = min(length - len(result), end - offset)
                expected = f"bytes {start}-{start + count - 1}/{part['size']}"
                for attempt in range(4):
                    if time.monotonic() >= self.deadline:
                        raise TimeoutError("Transfer deadline; owned partial retained")
                    request = urllib.request.Request(part.get("modelscope_url", part["url"]) + "?download=true", headers={
                        "Range": f"bytes={start}-{start + count - 1}", "Accept-Encoding": "identity",
                        "User-Agent": "guoxin-mobilevla-selected-006/1"})
                    try:
                        with self.opener.open(request, timeout=min(45, max(1, self.deadline - time.monotonic()))) as response:
                            if response.status != 206 or response.headers.get("Content-Range") != expected:
                                raise ValueError("Server ignored or changed exact Range")
                            data = response.read(count + 1)
                            if len(data) != count:
                                raise OSError("Truncated or oversized range response")
                        break
                    except (OSError, urllib.error.URLError):
                        if attempt == 3: raise
                result.extend(data); offset += count
                if len(result) == length: return bytes(result)
            origin = end
        raise ValueError("Range exceeds the pinned multipart ZIP")


def payload_offset(archive, row):
    offset = row["local_header_logical_offset"]
    header = archive.read_range(offset, 30)
    signature, version, flags, method, mtime, mdate, crc, compressed, expanded, name_len, extra_len = struct.unpack("<IHHHHHIIIHH", header)
    if signature != 0x04034B50 or method != row["compression_method"] or flags != row["flag_bits"]:
        raise ValueError("Local ZIP signature/method/flags differ from central directory")
    name_extra = archive.read_range(offset + 30, name_len + extra_len)
    name = name_extra[:name_len].decode("utf-8" if flags & 0x800 else "cp437")
    if name != row["path"] or (not flags & 8 and crc != int(row["crc32"], 16)):
        raise ValueError("Local ZIP filename or CRC differs")
    # ZIP64 fields appear in expanded-size then compressed-size order.
    sizes = [expanded, compressed]; extra = name_extra[name_len:]; i = 0
    while i + 4 <= len(extra):
        kind, size = struct.unpack_from("<HH", extra, i); body = extra[i + 4:i + 4 + size]; i += 4 + size
        if kind == 1:
            cursor = 0
            for j in (0, 1):
                if sizes[j] == 0xFFFFFFFF:
                    if cursor + 8 > len(body): raise ValueError("Truncated ZIP64 size")
                    sizes[j] = struct.unpack_from("<Q", body, cursor)[0]; cursor += 8
    if not flags & 8 and sizes != [row["uncompressed_size"], row["compressed_size"]]:
        raise ValueError("Local ZIP size differs from central directory")
    return offset + 30 + name_len + extra_len


def extract_cached(cache, output, row):
    decoder = zlib.decompressobj(-15) if row["compression_method"] == 8 else None
    compressed_sha = hashlib.sha256(); expanded_sha = hashlib.sha256(); crc = 0; count = 0
    with Path(cache).open("rb") as inp, Path(output).open("xb") as out:
        while data := inp.read(CHUNK):
            compressed_sha.update(data)
            plain = decoder.decompress(data) if decoder else data
            count += len(plain)
            if count > row["uncompressed_size"]: raise ValueError("Expanded payload exceeds locked size")
            out.write(plain); expanded_sha.update(plain); crc = zlib.crc32(plain, crc)
        if decoder and (not decoder.eof or decoder.unused_data or decoder.unconsumed_tail):
            raise ValueError("Deflate stream incomplete or contains trailing bytes")
        out.flush(); os.fsync(out.fileno())
    if count != row["uncompressed_size"] or f"{crc:08x}" != row["crc32"]:
        raise ValueError("Extracted bytes fail fixed ZIP CRC/size")
    reread = scan(output)
    if reread != {"size": count, "sha256": expanded_sha.hexdigest(), "crc32": f"{crc:08x}"}:
        raise ValueError("Output readback differs from streamed extraction")
    return {"path": row["path"], **reread, "compressed_sha256": compressed_sha.hexdigest(),
            "compressed_size": row["compressed_size"], "compression_method": row["compression_method"]}


def apply(plan, lock, destination, max_seconds):
    rows, parts = validated_locks(plan, lock); no_links(destination)
    if destination != BASE or sys.platform != "linux":
        raise ValueError("Apply is restricted to the dedicated SCNet Linux model namespace")
    destination.mkdir(parents=True, exist_ok=True); cache_dir = destination / ".selected-compressed-006"
    cache_dir.mkdir(exist_ok=True); no_links(cache_dir)
    if shutil.disk_usage(destination).free < plan["uncompressed_bytes"] + plan["compressed_payload_bytes"] + 1024**3:
        raise ValueError("Insufficient storage plus reserve")
    run_id = uuid.uuid4().hex; lock_path = destination / "transfer.lock"
    write_new(lock_path, {"run_id": run_id, "pid": os.getpid()})
    report = {"schema": "mobilevla-selected-rgb-rl-receipt-006-v1", "run_id": run_id, "repo": MODEL,
              "revision": REVISION, "central_directory_sha256": CD_SHA, "full_lfs_parts_sha_verified": False,
              "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "status": "failed", "files": [],
              "verified_crc32_and_size": False, "GPU_imported": False}
    archive = RemoteArchive(parts, time.monotonic() + max_seconds)
    try:
        for index, row in enumerate(sorted(rows, key=lambda x: x["compressed_size"])):
            relative_path = relative(row["path"]); target = destination.joinpath(*relative_path.parts); no_links(target)
            target.parent.mkdir(parents=True, exist_ok=True)
            compressed = cache_dir / (hashlib.sha256(row["path"].encode()).hexdigest() + ".deflate")
            state = compressed.with_suffix(".identity.json"); no_links(compressed); no_links(state)
            identity = {**row, "repo": MODEL, "revision": REVISION, "central_directory_sha256": CD_SHA}
            if state.exists() and read(state) != identity: raise ValueError("Cache identity differs")
            if compressed.exists() and not state.exists(): raise ValueError("Unowned compressed partial")
            if not state.exists(): write_new(state, identity)
            if not compressed.exists(): compressed.touch(exist_ok=False)
            count = compressed.stat().st_size
            if count > row["compressed_size"]: raise ValueError("Compressed cache exceeds expected size")
            data_offset = payload_offset(archive, row)
            with compressed.open("ab") as out:
                while count < row["compressed_size"]:
                    data = archive.read_range(data_offset + count, min(CHUNK, row["compressed_size"] - count))
                    out.write(data); out.flush(); count += len(data)
                    if count % (128 * 1024 * 1024) < CHUNK:
                        print(json.dumps({"event": "progress", "path": row["path"], "compressed_bytes": count}), flush=True)
            if target.exists():
                result = scan(target)
                if result["size"] != row["uncompressed_size"] or result["crc32"] != row["crc32"]:
                    raise ValueError("Existing final entry differs; no overwrite")
                result = {"path": row["path"], **result, "compressed_sha256": scan(compressed)["sha256"],
                          "compressed_size": row["compressed_size"], "compression_method": row["compression_method"]}
            else:
                partial = target.with_name(target.name + ".extract-" + run_id)
                result = extract_cached(compressed, partial, row)
                os.link(partial, target); partial.unlink()
            report["files"].append(result)
            print(json.dumps({"event": "entry_verified", "index": index + 1, **result}), flush=True)
        report["status"] = "completed"; report["verified_crc32_and_size"] = True
        write_new(destination / "extraction-receipt.json", report)
        return 0
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        report["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
        write_new(destination / ("transfer-" + run_id + ".json"), report)
        if lock_path.is_file() and read(lock_path).get("run_id") == run_id: lock_path.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "download"))
    parser.add_argument("--plan", type=Path, required=True); parser.add_argument("--volume-lock", type=Path, required=True)
    parser.add_argument("--max-seconds", type=int, default=10800)
    args = parser.parse_args(); plan = read(args.plan); lock = read(args.volume_lock); validated_locks(plan, lock)
    if args.action == "plan":
        print(json.dumps({"status": "offline_plan", "compressed_bytes": plan["compressed_payload_bytes"],
                          "expanded_bytes": plan["uncompressed_bytes"], "destination": str(BASE), "GPU_imported": False})); return 0
    if not 60 <= args.max_seconds <= 21600: parser.error("Transfer deadline must be 60..21600 seconds")
    return apply(plan, lock, BASE, args.max_seconds)


if __name__ == "__main__":
    raise SystemExit(main())
