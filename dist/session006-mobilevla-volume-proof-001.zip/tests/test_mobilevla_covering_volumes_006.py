"""Positive/negative cryptographic reconstruction tests; no HTTP/model/GPU."""
import contextlib
import hashlib
import io
from pathlib import Path
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import verify_mobilevla_covering_volumes_006 as subject


class Gaps:
    def __init__(self, raw, corrupt=False):
        self.raw = raw
        self.corrupt = corrupt
        self.calls = []

    def read_range(self, offset, length):
        self.calls.append((offset, length))
        raw = self.raw[offset:offset + length]
        if self.corrupt:
            raw = bytes([raw[0] ^ 1]) + raw[1:]
        return raw


class CoveringVolumeTests(unittest.TestCase):
    def make(self, directory):
        raw = b"PREFIX123" + b"selected-compressed-A" + b"GAP" + b"selected-compressed-B-long" + b"TRAIL"
        # Both selected payloads cross volume boundaries.
        cuts = [0, 18, 41, len(raw)]
        parts = [{"path": f"volume-{i}", "size": cuts[i + 1] - cuts[i],
                  "sha256": subject.sha(raw[cuts[i]:cuts[i + 1]])} for i in range(3)]
        a, b = raw.index(b"selected-compressed-A"), raw.index(b"selected-compressed-B-long")
        segments = []
        for name, start, length in [("A", a, len(b"selected-compressed-A")),
                                    ("B", b, len(b"selected-compressed-B-long"))]:
            path = Path(directory) / name
            data = raw[start:start + length]
            path.write_bytes(data)
            segments.append({"path": name, "start": start, "end": start + length,
                             "cache_file": str(path), "expected_sha256": subject.sha(data)})
        return raw, parts, segments

    def verify(self, parts, segments, archive, report):
        with contextlib.redirect_stdout(io.StringIO()):
            return subject.verify_streams(parts, segments, archive, time.monotonic() + 10, report)

    def test_cross_volume_reconstruction_authenticates_all_and_only_gap_requests(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw, parts, segments = self.make(tmp)
            archive = Gaps(raw)
            report = self.verify(parts, segments, archive, {})
            self.assertTrue(report["selected_RL_payloads_cryptographically_bound_to_published_volume_SHA256"])
            self.assertTrue(report["all_selected_cache_SHA256_match_extraction_receipt"])
            self.assertEqual(len(report["parts"]), 3)
            self.assertEqual(len(report["selected_cache_hashes"]), 2)
            self.assertEqual(report["gap_network_bytes"], len(b"PREFIX123GAPTRAIL"))
            for offset, count in archive.calls:
                self.assertFalse(any(s["start"] < offset + count and s["end"] > offset for s in segments))
            self.assertEqual(sum(x["bytes"] for p in report["parts"] for x in p["selected_cache_mappings"]),
                             sum(s["end"] - s["start"] for s in segments))

    def test_corrupt_gap_cannot_authenticate_volume(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw, parts, segments = self.make(tmp)
            report = {}
            with self.assertRaisesRegex(ValueError, "Complete covering volume SHA256 differs"):
                self.verify(parts, segments, Gaps(raw, corrupt=True), report)
            self.assertFalse(report["selected_RL_payloads_cryptographically_bound_to_published_volume_SHA256"])
            self.assertFalse(report["parts"][-1]["sha256_matches"])

    def test_correct_whole_parts_but_wrong_extraction_cache_sha_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw, parts, segments = self.make(tmp)
            segments[1]["expected_sha256"] = "0" * 64
            report = {}
            with self.assertRaisesRegex(ValueError, "differ from extraction receipt"):
                self.verify(parts, segments, Gaps(raw), report)
            self.assertTrue(all(x["sha256_matches"] for x in report["parts"]))
            self.assertFalse(report["all_selected_cache_SHA256_match_extraction_receipt"])

    def test_corrupt_selected_cache_cannot_authenticate_volume(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw, parts, segments = self.make(tmp)
            path = Path(segments[0]["cache_file"])
            data = path.read_bytes()
            path.write_bytes(bytes([data[0] ^ 1]) + data[1:])
            with self.assertRaisesRegex(ValueError, "Complete covering volume SHA256 differs"):
                self.verify(parts, segments, Gaps(raw), {})

    def test_overlap_rejected_before_any_network_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw, parts, segments = self.make(tmp)
            segments[1]["start"] = segments[0]["end"] - 1
            archive = Gaps(raw)
            with self.assertRaisesRegex(ValueError, "overlap"):
                self.verify(parts, segments, archive, {})
            self.assertEqual(archive.calls, [])

    def test_deadline_rejects_before_network_or_cache_hashing(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw, parts, segments = self.make(tmp)
            report = {}
            with self.assertRaises(TimeoutError):
                subject.verify_streams(parts, segments, Gaps(raw), time.monotonic() - 1, report)
            self.assertFalse(report["selected_RL_payloads_cryptographically_bound_to_published_volume_SHA256"])

    def test_actual_plan_coverage_cost_exactly_552355933_gap_bytes(self):
        import json
        root = Path(__file__).resolve().parents[1]
        plan = json.loads((root / "candidates/mobilevla-r1-session006/rl-entry-plan.json").read_text())
        lock = json.loads((root / "evidence/session006/source-mapping/mobilevla-volume-sources006.json").read_text())
        layout = subject.volume_layout(lock["parts"])
        selected = [(x["local_header_logical_offset"], x["local_header_logical_offset"] + 30 + x["compressed_size"])
                    for x in plan["entries"]]
        covered = [p for p in layout if any(a < p["end"] and b > p["start"] for a, b in selected)]
        self.assertEqual([p["path"] for p in covered], ["weight.zip.part-a" + chr(c) for c in range(ord("m"), ord("z") + 1)])
        self.assertEqual(sum(p["size"] for p in covered) - plan["compressed_payload_bytes"], 552355933)


if __name__ == "__main__":
    unittest.main()
